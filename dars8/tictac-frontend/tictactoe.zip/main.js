let cells = document.querySelectorAll('.cell');
let status = document.querySelector('.game--status');
let restart = document.querySelector('.game--restart');
let template = new Array(9).fill('')
let checkk = true


function huWon(){
    console.log("Siz yutdiz");
    status.textContent = 'You WON'
    for (let i = 0; i < cells.length; i++) {
        cells[i].style.pointerEvents = 'none'
    }
    template = new Array(9).fill('')
    return
}

function AIWon(){
    console.log("Men yutdim");
    status.innerHTML = 'AI WON'
    for (let i = 0; i < cells.length; i++) {
        cells[i].style.pointerEvents = 'none'
    }
    template = new Array(9).fill('')
    return
}

function draw(){
    console.log("Durrang");
    status.innerHTML = 'Draw'
    for (let i = 0; i < cells.length; i++) {
        cells[i].style.pointerEvents = 'none'
    }
    template = new Array(9).fill('')
    return
}

function check(checkk) {
    if (template[0] === '1' && template[1] === '1' && template[2] === '1' || template[3] === '1' && template[4] === '1' && template[5] === '1' || template[6] === '1' && template[7] === '1' && template[8] === '1' || template[0] === '1' && template[3] === '1' && template[6] === '1' || template[1] === '1' && template[4] === '1' && template[7]  === '1' || template[2] === '1' && template[5] === '1' && template[8]  === '1' || template[0] === '1' && template[4] === '1' && template[8]  === '1' || template[2] === '1' && template[4] === '1' && template[6]  === '1' || template[0] == '1' && template[4] == '1' && template[8] == '1') {
        huWon()
        return
    }
    if (template[0] === '0' && template[1] === '0' && template[2] === '0' || template[3] === '0' && template[4] === '0' && template[5] === '0' || template[6] === '0' && template[7] === '0' && template[8] === '0' || template[0] === '0' && template[3] === '0' && template[6] === '0' || template[1] === '0' && template[4] === '0' && template[7]  === '0' || template[2] === '0' && template[5] === '0' && template[8]  === '0' || template[0] === '0' && template[4] === '0' && template[8]  === '0' || template[2] === '0' && template[4] === '0' && template[6]  === '0') {
        AIWon()
        return
    }
    if (checkk) {
        if (template[0] === '1' && template[1] === '1' && template[2] === '1' || template[3] === '1' && template[4] === '1' && template[5] === '1' || template[6] === '1' && template[7] === '1' && template[8] === '1' || template[0] === '1' && template[3] === '1' && template[6] === '1' || template[1] === '1' && template[4] === '1' && template[7]  === '1' || template[2] === '1' && template[5] === '1' && template[8]  === '1' || template[0] === '1' && template[4] === '1' && template[8]  === '1' || template[2] === '1' && template[4] === '1' && template[6]  === '1') {
            huWon()
            return
        }
        else if (template[0] === '0' && template[1] === '0' && template[2] === '0' || template[3] === '0' && template[4] === '0' && template[5] === '0' || template[6] === '0' && template[7] === '0' && template[8] === '0' || template[0] === '0' && template[3] === '0' && template[6] === '0' || template[1] === '0' && template[4] === '0' && template[7]  === '0' || template[2] === '0' && template[5] === '0' && template[8]  === '0' || template[0] === '0' && template[4] === '0' && template[8]  === '0' || template[2] === '0' && template[4] === '0' && template[6]  === '0') {
            AIWon()
            return
        }
        else{
            draw() 
            return
        }
    }
}


for (let cell of cells) {
    cell.onclick = () =>{
        let id = cell.getAttribute('data-cell-index')
        let count = 0
        if(!template[id]){
            let random = Math.round(Math.random() * 8)
            for(let temp of template){
                if(temp){
                    count++
                }
            }
            if (count > 6) {
                template[id] = '1'
                cell.textContent = 'X'
                check(checkk)
                return
            }
            while(template[random] || id == random || random <= 0 || template[random]){
                random = Math.round(Math.random() * 8)
            }

                cell.textContent = 'X'
                template[id] = '1'
                cells[random].textContent = 'O'
                template[random] = '0'
                check()
        }else{
            alert("Siz jinnixonadan qochganmisiz diymana")
        }

        console.log(template);
    }
}



restart.onclick = () =>{
    for (let i = 0; i < cells.length; i++) {
        cells[i].innerHTML = ''
        cells[i].style.pointerEvents = 'auto'
    }
    template = new Array(9).fill('')
    status.innerHTML = ''
}