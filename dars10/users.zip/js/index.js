let usersList = document.querySelector('.all-users')
let currentDate = document.querySelector('#dates-range').value = new Date().getDate() + "/" + new Date().getMonth() +1 + "/" + new Date().getFullYear()
let navs = document.querySelectorAll('.nav')
let globalFilter = 'all'
let fullname = document.querySelector('#fullname')
let username = document.querySelector('#username')
let email = document.querySelector('#email')
let about = document.querySelector('#about')
let changePassword = document.querySelector('#changePassword')
let newPassword = document.querySelector('#newPassword')
let confirmPassword = document.querySelector('#confirmPassword')
let SaveChange = document.querySelector('.btn-primary')
let users = []


SaveChange.onclick = function(e){
    if (fullname.value.trim().length < 5 || username.value.trim().length < 5 || email.value.trim().length < 5 || about.value.trim().length < 5 || changePassword.value.trim().length < 5 || confirmPassword.value.trim().length < 5 || newPassword.value.trim().length < 5 || newPassword.value != confirmPassword.value){
        e.preventDefault()
        alert('Kiritilgan ma\'lumotlar xato')
    }else{
        users.push(
            {
                fullname: fullname.value, username: username.value, email: email.value, about: about.value, password: newPassword, active: false
            }
        )
        e.preventDefault()

        usersList.innerHTML += `
        <tr class="users-list">
                      <td class="align-middle">
                        <div class="custom-control custom-control-inline custom-checkbox custom-control-nameless m-0 align-top">
                          <input type="checkbox" class="custom-control-input" onchange="checkBox(event)" id="item-12">
                          <label class="custom-control-label" for="item-12"></label>
                        </div>
                      </td>
                      <td class="align-middle text-center">
                        <div class="bg-light d-inline-flex justify-content-center align-items-center align-top" style="width: 35px; height: 35px; border-radius: 3px;"><i class="fa fa-fw fa-photo" style="opacity: 0.8;"></i></div>
                      </td>
                      <td class="text-nowrap align-middle">${fullname.value}</td>
                      <td class="text-nowrap align-middle"><span>${currentDate}</span></td>
                      <td class="text-center align-middle"><i id="ActiveButton" onclick="AvticeButton()" class="fa fa-fw text-secondary cursor-pointer fa-toggle-off"></i></td>
                      <td class="text-center align-middle">
                        <div class="btn-group align-top">
                            <button class="btn btn-sm btn-outline-secondary badge" type="button" data-toggle="modal" data-target="#user-form-modal">Edit</button>
                            <button class="btn btn-sm btn-outline-secondary badge" type="button"><i class="fa fa-trash"></i></button>
                        </div>
                      </td> 
                    </tr>
        `
        window.localStorage.setItem('users', JSON.stringify(users))
        console.log(users);
    }
}



function checkBox($event){
    console.log($event.srcElement.checked);
}

function onclickk(){
    console.log('this');
}


function AvticeButton() {
    var elements = document.querySelectorAll("#ActiveButton");
    for(let element of elements) {
        console.log(elements.indexOf(JSON.stringify()));
        element.onclick = (e) => {  
            e.preventDefault()
            element.classList.toggle("fa-toggle-on")
            if(element.classList.contains('fa-toggle-on')){

            }
            // document.querySelectorAll('.fa-toggle-off').forEach((elem, i)=>{
            //     if (elem.classList.contains('fa-toggle-on')) {
            //         temp++
            //     }
            // })
        }
    }
}




for(let nav of navs) {
	nav.onclick = (e) => {  
        e.preventDefault()
		navs.forEach(el => el.classList.remove('active'))
		nav.classList.add('active')
		globalFilter = e.target.textContent
	}
}